![](https://img.shields.io/badge/Foundry-v0.8.6-informational)
![Latest Release Download Count](https://img.shields.io/github/downloads/kandashi/map-coords/latest/module.zip) -->![Forge Installs](https://img.shields.io/badge/dynamic/json?label=Forge%20Installs&query=package.installs&suffix=%25&url=https%3A%2F%2Fforge-vtt.com%2Fapi%2Fbazaar%2Fpackage%2Fmap-coords&colorB=4aa94a)

# Map Coordinates

Add coordinates to any square or hex map. Use the Measurement Controls menu with the Map icon to toggle between modes.

Set the numbering style, and offset in the module settings.

Alt-Click to "ping" your mouse location with its coordinates. (keybind changeable in module settings)